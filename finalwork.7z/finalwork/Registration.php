<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration</title>
    <link rel="stylesheet" href="assets/css/Registration.css">
</head>

<body>
 <div class="container">
    <section>
      <h1>Регистрация</h1>
        <div class="form1" >
        <input type="text" id="FName" placeholder="Имя">
        <input type="text" id="LName" placeholder="Фамилия">
        <input type="text" id="Email" placeholder="Почта">
        <input type="text" id="Login" placeholder="Логин">
        <input type="password" id="Password" placeholder="Пароль"> 
        <button type="submit" onclick="Registration()">Регистрация</button>
        <a href="http://finalwork"><button type="submit" id="niz">Назад</button></a>
        <p id="korova"></p>
        </div>  
    </section>
 </div>
 <script src="assets/js/Registration.js"></script>
</body>
</html>