function Search(event) {
    event.preventDefault(); 
    var ss = document.getElementById('search').value;

    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'search.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
            document.getElementById('Result').innerHTML = xhr.responseText;
        }
    };
    
    xhr.send('search=' + encodeURIComponent(ss)); 
}