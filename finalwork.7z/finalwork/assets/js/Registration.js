function Registration(){
    const xhr = new XMLHttpRequest();
    const data = new FormData();
    data.append("Name",document.getElementById("FName").value);
    data.append("Surname",document.getElementById("LName").value);
    data.append("Email",document.getElementById("Email").value);
    data.append("Login",document.getElementById("Login").value);
    data.append("Password",document.getElementById("Password").value);

    xhr.open("POST","Register.php",true);
    xhr.onload = function(){
        if(xhr.status >= 200 && xhr.status < 400){
            let result = JSON.parse(xhr.responseText);
            switch(result.status){
                case "Empty input":
                    document.getElementById("korova").innerText= result.message;
                break;
                case "Error data":
                    document.getElementById("korova").innerText= result.message;
                break;
                case "Success":
                    document.getElementById("korova").innerText= result.message;
                break;
            }
        }
        else{
            document.getElementById("korova").innerText = xhr.status;
        }
    }
    xhr.send(data);
    
}