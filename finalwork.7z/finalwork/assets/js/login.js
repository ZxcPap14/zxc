function Login(){
    const xhr = new XMLHttpRequest();
    const data = new FormData();
    data.append("Login",document.getElementById("Login").value);
    data.append("Password",document.getElementById("Password").value);

    xhr.open("POST","sender.php",true);
    xhr.onload = function(){
        if(xhr.status >= 200 && xhr.status < 400){
            console.log("Ответ получен");
            let result = JSON.parse(xhr.responseText);
            console.log(result);
            switch(result.status){
                case "Empty input":
                    document.getElementById("oshibka").innerText= result.message;
                break;
                case "Error data":
                    document.getElementById("oshibka").innerText= result.message;
                break;
                case "Success":
                    document.getElementById("oshibka").innerText= result.message;
                break;
            }
        }
        else{
            console.log("Ошибка отправки:"+xhr.status);
        }
    }
    xhr.send(data);
    
}