<?php

$dbh = new PDO('mysql:host=localhost;dbname=Final', 'root', '');
if(isset($_POST['Login'])){
   if(!empty($_POST['Login'] && !empty($_POST['Password']))){
    $stmt = $dbh->prepare("SELECT * FROM humans WHERE Login = :login AND Password = :password");
    $stmt->execute([
        "login" => $_POST['Login'],
        "password" => $_POST['Password']
    ]);
    $result = $stmt->fetch();
    if(!empty($result['Name'])){
        echo json_encode([
            "status"=> "Success",
            "message" => "Успешный вход!!!!",
            "data" => $result
        ]);
    }
    else{
        echo json_encode([
            "status"=> "Error data",
            "message" => "Данные не найдены в базе."
        ]);
    }
   }
   else{
    echo json_encode([
        "status"=> "Empty input",
        "message" => "Поле пусто."
    ]);
   }
    
}


?>