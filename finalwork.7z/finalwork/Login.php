<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="assets/css/Login.css">
</head>

<body>
<div class="container">
    <section>
    <h1>Вход</h1>
        <input type="text" name="Login" id="Login" placeholder="Логин">
        <input type="password" id="Password" placeholder="Пароль"> 
        <button type="submit" onclick="Login()">Войти</button>
        <a href="http://finalwork"><button type="submit" id="niz">Назад</button></a>
        <p id="oshibka"></p>
    </section>
</div>
<script src="assets/js/login.js"></script>

</body>
</html>