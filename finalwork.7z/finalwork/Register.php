<?php

$dbh = new PDO('mysql:host=localhost;dbname=Final', 'root', '');

if(isset($_POST['Name']) && isset($_POST['Surname']) && isset($_POST['Email']) && isset($_POST['Login']) && isset($_POST['Password'])){
    
    if(empty($_POST['Name']) || empty($_POST['Login']) || empty($_POST['Password']) || empty($_POST['Email'])){
        echo json_encode([
            "status"=> "Empty input",
            "message" => "Заполните имя, логин, пароль и почту"
        ]);
    } else {
        $stmt = $dbh->prepare("INSERT INTO humans (Name, Surname, Email, Login, Password) VALUES (:name, :surname, :email, :login, :password)");
        $stmt->execute([
            "name" => $_POST['Name'],
            "surname" => $_POST['Surname'],
            "email" => $_POST['Email'],
            "login" => $_POST['Login'],
            "password" => $_POST['Password']
        ]);
        echo json_encode([
            "status"=> "Success",
            "message" => "Регистрация прошла успешно",
        ]);
    }
}

?>
