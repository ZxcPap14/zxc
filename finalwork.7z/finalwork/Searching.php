
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search</title>
    <link rel="stylesheet" href="assets/css/Search.css">
</head>

<body>
  <form onsubmit="Search(event)" class="container">
  <h1 class="Finder">Поиск</h1>
  <input type="text" id="search" name="search" placeholder="Поиск">
  <button type="submit">Поиск</button><a class="text" href="http://finalwork">Назад</a>
  <div id="Result"></div>
</form>

</div>
<script src="assets/js/Search.js"></script>
</body>
</html>