<?php
$pdo = new PDO('mysql:host=localhost;dbname=Final', 'root', '', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
$Search = $_POST['search'];

if (!isset($Search) || empty($Search)) {
    die("Пожалуйста, введите текст для поиска.");
}

try {
    $stmt = $pdo->prepare('SELECT * FROM humans WHERE Name LIKE :search');
    $stmt->execute(['search' => '%'. $Search. '%']);
    $results = $stmt->fetchAll();
    foreach ($results as $result) {
        echo '<p>'. $result['Name'], ' ', $result['Surname'], ' ', $result['Email'], ' ', $result['Login'] . '</p>';
    }
} catch (PDOException $e) {
    die("Ошибка: ". $e->getMessage());
}
?>